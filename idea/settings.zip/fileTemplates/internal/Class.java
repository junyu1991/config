#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
    @author ${USER}
    @version 1.0.0
    @date ${DATE} ${TIME}
    @description TODO
**/
public class ${NAME} {
}
